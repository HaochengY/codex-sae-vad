# VAD Compass

Video-level VAD adaptation of the SegCompass sparse-concept pathway using InternVL2 as the frozen visual-language backbone.

The training objective is:

```text
L = lambda_grpo * GRPO(format + answer reward)
  + lambda_bce * BCE(video_abnormal_probability, video_label)
  + lambda_recon * SAE reconstruction loss
```

All paths are command-line parameters. Relative paths are resolved against `--project-root`; JSON video paths are converted to portable relatives under `--dataset-root`.

Smoke run:

```bash
/root/miniconda3/envs/mllm/bin/python scripts/train_vad_compass_internvl2_sht.py \
  --project-root /root/codex/codex-compass \
  --data ../data/sht_clip_32_160_conversations_filtered.json \
  --dataset-root ../../autodl-tmp/sht_clip_32_160 \
  --model-path ../../autodl-tmp/get_hf/InternVL2 \
  --output-dir outputs/vad_compass_smoke \
  --smoke
```

The SHT clip JSON has normal examples in `training` and abnormal examples in `testing`, so the training script defaults to `--train-split all`. Override it only if you have a dataset with both classes in the requested split.

By default, GRPO evaluates both binary candidate answers (`normal` and `abnormal`) inside each group. Pass `--sample-actions` to use stochastic Bernoulli rollouts instead.

Full run wrapper:

```bash
cd /root/codex/codex-compass
bash scripts/run_vad_compass_sht.sh
```

Portable JSON conversion:

```bash
/root/miniconda3/envs/mllm/bin/python scripts/prepare_portable_sht_json.py \
  --input-json ../data/sht_clip_32_160_conversations_filtered.json \
  --output-json data/sht_clip_32_160_conversations_filtered_portable.json
```
